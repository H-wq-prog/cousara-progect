
# Little Lemon Booking App

## Setup
1. npm install
2. npm start
