
import { render, screen } from "@testing-library/react";
import BookingForm from "./BookingForm";

test("renders booking form", () => {
  render(<BookingForm />);
  expect(screen.getByText(/Book Table/i)).toBeInTheDocument();
});
