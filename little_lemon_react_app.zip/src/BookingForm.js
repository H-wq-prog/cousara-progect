
import React, { useState } from "react";

function BookingForm() {
  const [form, setForm] = useState({
    date: "",
    time: "",
    guests: "",
    name: "",
    email: ""
  });

  const [error, setError] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.date || !form.time || !form.guests || !form.name || !form.email) {
      setError("All fields are required");
      return;
    }
    setError("");
    alert("Booking confirmed!");
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>Date:
        <input type="date" name="date" onChange={handleChange} />
      </label>

      <label>Time:
        <input type="time" name="time" onChange={handleChange} />
      </label>

      <label>Guests:
        <input type="number" name="guests" onChange={handleChange} />
      </label>

      <label>Name:
        <input type="text" name="name" onChange={handleChange} />
      </label>

      <label>Email:
        <input type="email" name="email" onChange={handleChange} />
      </label>

      {error && <p style={{color:"red"}}>{error}</p>}

      <button type="submit">Book Table</button>
    </form>
  );
}

export default BookingForm;
